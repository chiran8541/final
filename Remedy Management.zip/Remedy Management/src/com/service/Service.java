package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.chrono.IsoEra;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import com.doa.OrclDatabase;
import com.models.User;
import com.models.UserRequest;

public class Service {
	public static void addUser(User u)
	{
		try
		{
			Connection con = OrclDatabase.getConnection();
			PreparedStatement ps = null;
			int userId = 0;
			
			
			//checking the userid in database
			String query = "select userid from users";
						 
			ps = con.prepareStatement(query,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = ps.executeQuery();
			if(rs.next() == false)
			{
				
				userId = 0;
				
			}	
			else
			{                                                                                                                                                                               
				
				rs.last();
				userId = rs.getInt(1);
				
			}
			
			userId = userId + 1;
			
			//adding user data to database 
			String query1 = "insert into users(userid, fname, lname, mobileno, email, password) values(?, ?, ?, ?, ?, ?)";
			ps = con.prepareStatement(query1);
			ps.setInt(1, userId);
			ps.setString(2, u.getFname());
			ps.setString(3, u.getLname());
			ps.setString(4, u.getMobile());
			ps.setString(5, u.getEmail());
			ps.setString(6, u.getPassword());
			
			ps.executeUpdate();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void addDetails(UserRequest u, String username)
	{
		try{
			  Connection con = OrclDatabase.getConnection();
			  PreparedStatement ps = null;
			  // finding userid of user
			  String query = "select Userid from users where email = ?";
			   
			  ps = con.prepareStatement(query);
			  ps.setString(1, username);
			  ResultSet rs = ps.executeQuery();
			  
			  int userid = 0;
			  while(rs.next())
			  {
				  userid = rs.getInt(1);
			  }
			  
			  //creating auto generating recordid
			  String recordId = "RA";
			  
			  Calendar c = Calendar.getInstance();
			  recordId += c.get(Calendar.DATE) + "" + c.get(Calendar.MONTH) + "" + c.get(Calendar.YEAR) + "" + c.get(Calendar.HOUR) + "" + c.get(Calendar.MINUTE) + "" + c.get(Calendar.SECOND);
			  
			  
			  //getting today's date
			  LocalDate l = LocalDate.now();
			  java.sql.Date date = java.sql.Date.valueOf(l);
			  
			  String query1 = "insert into userdetails values(?, ?, ?, ?, ?, ?, ?)";
			  ps = con.prepareStatement(query1);
			  
			  ps.setString(1, recordId);
			  ps.setString(2, u.getSummary());
			  ps.setString(3, u.getPriority());
			  ps.setDate(4, date);
			  ps.setString(5, u.getDetails());
			  ps.setString(6, "In-Progress");
			  ps.setInt(7, userid);
			 
			  ps.executeUpdate();
			  
			  
			  
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		  
		
		  
	}
	
	public static ArrayList<LinkedHashMap<Integer, String>> createArray()
	{
		ArrayList<LinkedHashMap<Integer, String>> arr = new ArrayList<>();
		
		try{
			Connection con = OrclDatabase.getConnection();
			String query = "select * from resources";
			PreparedStatement ps = con.prepareStatement(query);
			
			ResultSet rs = ps.executeQuery();
			
			
			while(rs.next())
			{
				LinkedHashMap<Integer, String> lm = new LinkedHashMap<>();
				
				lm.put(rs.getInt(1), rs.getString(3));
				
				arr.add(lm);
				
			}
			
			
			
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return arr;
	}
	
	public static String fun()
	{
		return "hello";
	}
	
	
	
	
	
	
	
}
