package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.adminDAO;
import com.DAO.adminDAOImpl;

public class Controller extends HttpServlet{
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doPost(req, res);
	}
	
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String uname = req.getParameter("username");
		HttpSession session;
		if(uname.equals("admin"))
		{
			session = req.getSession(true);
			session.setMaxInactiveInterval(10); // 30 seconds
			 
			session.setAttribute("username", uname);
			
			RequestDispatcher rd = req.getRequestDispatcher("views/test.jsp");
			
			
		}
		else
		{
			session = req.getSession(true);
			session.setAttribute("username", uname);
			session.setMaxInactiveInterval(30); // 30 seconds
			 
			/*RequestDispatcher rd = req.getRequestDispatcher("views/ticket.jsp");
			rd.forward(req, res);*/
			adminDAO ad = new adminDAOImpl();
			List<String> list = ad.getAllId();
			System.out.println(list);
			
			res.sendRedirect("views/adminDetails.jsp");
			
		}
		
		
		
		
		
		
		
	}
	
	
}
