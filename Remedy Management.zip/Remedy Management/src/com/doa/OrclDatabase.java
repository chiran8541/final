package com.doa;

import java.sql.Connection;
import java.sql.DriverManager;

public class OrclDatabase {
	
	public static Connection getConnection()
	{
		
		Connection con = null;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "");
			
			
		}catch(Exception e)
		{
			
		}
		return con;
	}
	
	
}
